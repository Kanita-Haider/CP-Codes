#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long 
#define mp make_pair
#define pb push_back
#define mset(a, b) memset(a, b, sizeof(a))
#define FAST ios_base::sync_with_stdio(false);cin.tie(NULL)
using namespace std;

const int lim=1e5+5;
vector<int>adj[lim];
int vis[lim];
bool flag=true;


void bfs(int src){

    vis[src]=1;
    queue<int>q;
    q.push(src);
    
    while(!q.empty()){
        int u=q.front();
       // cout<<u<<endl;
        q.pop();
         for(int i=0; i<adj[u].size();i++){
            int v=adj[u][i];
            if(vis[v]==0 ){
                if(vis[u]==1) vis[v]=2;
                else vis[v]=1;
                q.push(v);
            } 
            else if( vis[v]==vis[u]) {
                //cout<<v<<" "<<u<<endl;
                flag=false;
                }
        }
    }
}


int main()
{
 FAST;
    freopen("Input6.txt","r",stdin);
    freopen("Output6.txt","w",stdout);

 int t; cin>>t;
 while(t--){

 
 mset(vis,0);
int n,m;
cin>>n>>m;
for(int i=0; i<=2*n;i++) adj[i].clear();

 for(int i=0; i<m;i++){
     int u,v;
    cin>>u>>v;
    adj[u].pb(v);
    adj[v].pb(u);
}

bfs(1);


if(!flag) cout<<"Incorrect"<<endl;
else  cout<<"Correct"<<endl;


}
fclose(stdout);
fclose(stdin);
return 0;
}