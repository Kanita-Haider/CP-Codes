#include<bits/stdc++.h>
using namespace std;

int main(){

   freopen("Input6.txt","w",stdout);
    int t,n,m,u,v;
      t=10;
         cout << t << endl;
    while (t--)
    {
        int n = rand() % 10 + 1;
        int m = rand() % 10 + 1;
            
        cout << n << " " << m << endl;
        for (int i = 0; i < m; i++)
        {
            cout << (rand() % 10 + 1) << " " <<(rand() % 10 + 1)<<endl;
        }
    
    }
    fclose(stdout);
    return 0;
}   